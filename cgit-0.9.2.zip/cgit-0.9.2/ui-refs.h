#ifndef UI_REFS_H
#define UI_REFS_H

extern void cgit_print_branches(int maxcount);
extern void cgit_print_tags(int maxcount);
extern void cgit_print_refs();

#endif /* UI_REFS_H */
