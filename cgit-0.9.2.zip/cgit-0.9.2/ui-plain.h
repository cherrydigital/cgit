#ifndef UI_PLAIN_H
#define UI_PLAIN_H

extern void cgit_print_plain(struct cgit_context *ctx);

#endif /* UI_PLAIN_H */
